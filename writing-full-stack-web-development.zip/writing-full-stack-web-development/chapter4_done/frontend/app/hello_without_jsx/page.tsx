import React from "react";
export default function Page() {
    return React.createElement('h1', null, `Hello, Next.js!`);
}
