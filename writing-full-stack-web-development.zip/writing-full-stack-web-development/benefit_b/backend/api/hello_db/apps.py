from django.apps import AppConfig


class HelloDbConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api.hello_db"
